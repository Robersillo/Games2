<?php
$dbhost="localhost";
$dbname="basededatos";
$dbuser="usuario";
$dbpass="clave";

$uploaddir="/tmp/";
$con=mysql_connect($dbhost,$dbuser,$dbpass);
?>
